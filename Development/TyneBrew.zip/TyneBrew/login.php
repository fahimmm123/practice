<?php
ini_set('display_errors', 1);

require 'DB.php';

$db = new DB;
session_start();

if (isset($_POST['submit'])) {
    if (isset($_POST['username']) && isset($_POST['password'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        // Prepare query to get user data based on username
        $query = $db->connect()->prepare("SELECT username, password FROM Users WHERE username = ?");
        $query->execute([$username]);

        // Fetch user data
        $user = $query->fetch(PDO::FETCH_ASSOC);

        // Check if the user exists and if the password matches
        if ($user && password_verify($password, $user['password'])) {
            // Password is correct, set session and redirect
            $_SESSION['username'] = $username;
            header('Location: index.php');
            exit(); // Make sure to exit after redirect
        } else {
            echo "Incorrect credentials.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h1>Login </h1>

    <form method="post">
        <label for="username">Username</label><br>
        <input type="text" placeholder="Please enter your username" name="username" id="username" required><br>

        <label for="password">Password:</label><br>
        <input type="password" placeholder="Please enter your password" name="password" id="password" required><br><br>

        <input type="submit" name="submit" value="Login">
    </form>
</body>
</html>
