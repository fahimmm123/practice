<?php

ini_set("display_errors", 1);
require "DB.php";
require "products.php";

$db = new DB;



?>




<!DOCTYPE html>
<html>

<head>
    <title>Tyne Brew Coffee</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Encode+Sans+Semi+Expanded:wght@100;200;300;400;500;600;700;800;900&family=Permanent+Marker&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>

    <div class="navbar">
        <div class="logo"> <img src="Images/Logo.png" height="2%" width="35%">

        </div>
        <ul class="nav-list">
            <li><a href="index.php"><i class="fa fa-fw fa-home"></i>Home</a></li>
            <li><a href="login.php"><i class="fa fa-address-book"> </i> LOGIN</a></li>
            <li><a href="register.php"><i class="fa fa-sign-in"></i> REGISTER</a></li>
        </ul>
        <div class="rightNav">
            <input type="text" id="search" placeholder="Search...">
        </div>
    </div>

   

    <div class="main">
       
        <form method="post">
        <h3><centre>SIGN IN</centre></h3>
        <input type="email" placeholder="Email.." name="email">
        <input type="text" placeholder="Username.."name="username">
        <input type="password" placeholder="Password.."name="password">
        <input type="password" placeholder="Confirm Password.."name="confpass">
        <button type="submit" name="register" class="button button1">SUBMIT</button>
    </form>
    </div>

    <?php
    if(isset($_POST['register'])){
        //set post variables
        $email = $_POST['email'];
        $username = $_POST['username'];
        $password = $_POST['password'];
        $confpass = $_POST['confpass'];

        if(empty($email) || empty($username) || empty($password) || empty($confpass)){
            }

        if($password != $confpass){
            echo'Your password do not matach!';
            die();

        }
        
        if(strlen($email) < 5 || strlen($email) > 50){
            echo ' Your email does not meet the length requirements!';
            die();

        }

        if(strlen($username) < 3 || strlen($username) > 12){

            echo ' Your username does not meet the length requirements!';
            die();

        }

        if(strlen($password) < 3 || strlen($password) > 100){

            echo ' Your password does not meet the length requirements!';
            die();

        }


        if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
            echo 'Invalid Email';
            die();
        }

        if(!preg_match("/^[a-zA-Z0-9_]*$/", $username)){

            echo'Invalid username!';
            die();
        }

        $conn = $db->connect();
        if(!$conn){echo 'Database failed to connect!';}
        $emailQuery = $conn->prepare("SELECT * FROM Users WHERE email = :email OR username = :username");
        $emailQuery->bindParam(':email', $email, PDO::PARAM_STR);
        $emailQuery->bindParam(':username', $username, PDO::PARAM_STR);
        $emailQuery->execute();

        if($emailQuery->rowCount() > 0){
            echo 'Email or username is already in use'; 
            die();
        }
        else{
            $encryptedPassword = password_hash($password, PASSWORD_DEFAULT);
            $uuid = generateUUID();
            $insertQuery = $conn->prepare("INSERT INTO Users (email, username, password, UUID) Values (:email, :username, :password, :uuid)");
            $insertQuery->bindParam(":email", $email, PDO::PARAM_STR);
            $insertQuery->bindParam(":username", $username, PDO::PARAM_STR);
            $insertQuery->bindParam(":password", $encryptedPassword, PDO::PARAM_STR);
            $insertQuery->bindParam(":uuid", $uuid, PDO::PARAM_STR);


            $insertQuery->execute();

            if ($insertQuery) {
                // Display a simple JavaScript alert for success
                echo '<script type="text/javascript">
                        alert("Account created successfully!");
                      </script>';
            }

        }
    }

        function generateUUID(){
            return time() . bin2hex(random_bytes(8));
        }

    ?> 


    
<br><br><br><br><br><br><br><br><br><br>
    
    <footer class="footer">
            <div class="waves">
                <div class="wave" id="wave1"></div>
                <div class="wave" id="wave2"></div>
                <div class="wave" id="wave3"></div>
                <div class="wave" id="wave4"></div>
            </div>
            <ul class="social-icon">
                <li class="social-icon__item"><a class="social-icon__link"
                        href="https://en-gb.facebook.com/NewcastleCityCouncil/">
                        <ion-icon name="logo-facebook"></ion-icon>
                    </a></li>
                <li class="social-icon__item"><a class="social-icon__link" href="https://x.com/NewcastleCC">
                        <ion-icon name="logo-twitter"></ion-icon>
                    </a></li>

                <li class="social-icon__item"><a class="social-icon__link"
                        href="https://www.youtube.com/user/NewcastleCCUK">
                        <ion-icon name="logo-instagram"></ion-icon>
                    </a></li>
            </ul>
            <ul class="menu">
                <li class="menu__item"><a class="menu__link" href="indexx.php">Home</a></li>
                <li class="menu__item"><a class="menu__link" href="login.php">Events</a></li>
                <li class="menu__item"><a class="menu__link" href="signin.php">Sign in</a></li>


            </ul>
            <p>&copy;2024 Local Community | All Rights Reserved</p>
        </footer>
        <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
        <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

</body>

</html>