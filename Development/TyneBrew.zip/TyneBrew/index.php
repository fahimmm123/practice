<?php

ini_set("display_errors", 1);
require "DB.php";
require "products.php";

$db = new DB();

$query = $db->connect()->prepare("SELECT * FROM tbl_products");
$query->execute();

$product = array();

while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
    $id = $row['id'];
    $name = $row['name'];
    $image = $row['image'];
    $product[] = new Product($id, $name, $image);
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Tyne Brew Coffee</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Encode+Sans+Semi+Expanded:wght@100;200;300;400;500;600;700;800;900&family=Permanent+Marker&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>

<body>
    <div class="navbar">
        <div class="logo"> <img src="Images/Logo.png" height="2%" width="35%">

        </div>
        <ul class="nav-list">
            <li><a href="index.php"><i class="fa fa-fw fa-home"></i>Home</a></li>
            <li><a href="login.php"><i class="fa fa-address-book"> </i> LOGIN</a></li>
            <li><a href="register.php"><i class="fa fa-sign-in"></i> REGISTER</a></li>
        </ul>
        <div class="rightNav">
            <input type="text" id="search" placeholder="Search...">
        </div>
    </div>
    

    <div class="image-container">
        <img src="Images/banner01.jpg" alt="Coffee Image">
        <div class="image-title">
            <h1>Tyne Brew Coffee</h1>
            <h2>Tyne Brew Coffee: The Art of Blending Perfection,<br>Where Every Bean is Carefully Selected and Expertly
                Crafted to Deliver a Flavor Experience Like No Other</h2>
            <br>
            <br>
            <button class="button button1"> More about us</button>
            <button class="button button1">Explore our products</button>
        </div><br><br><br>

    </div>
    <br><br><br><br><br><br><br><br><br><br>

    <div class="image-container">
        <img src="Images/Aboutus.jpg" alt="Coffee Image">
        <div class="image-title">
            <h1> <span style="color: orange;">About Us</span> </h1>
            <h2>Tyne Brew Coffee: The Art of Blending Perfection, Where Every Bean is Carefully Selected and Expertly
                Crafted to Deliver a Flavor Experience Like No Other</h2><br><br>

        </div><br><br><br>

    </div>


    <br><br><br><br><br><br><br><br><br><br>

    <footer class="footer">
        <div class="waves">
            <div class="wave" id="wave1"></div>
            <div class="wave" id="wave2"></div>
            <div class="wave" id="wave3"></div>
            <div class="wave" id="wave4"></div>
        </div>
        <ul class="social-icon">
            <li class="social-icon__item"><a class="social-icon__link"
                    href="https://en-gb.facebook.com/NewcastleCityCouncil/">
                    <ion-icon name="logo-facebook"></ion-icon>
                </a></li>
            <li class="social-icon__item"><a class="social-icon__link" href="https://x.com/NewcastleCC">
                    <ion-icon name="logo-twitter"></ion-icon>
                </a></li>

            <li class="social-icon__item"><a class="social-icon__link"
                    href="https://www.youtube.com/user/NewcastleCCUK">
                    <ion-icon name="logo-instagram"></ion-icon>
                </a></li>
        </ul>
        <ul class="menu">
            <li class="menu__item"><a class="menu__link" href="indexx.php">Home</a></li>
            <li class="menu__item"><a class="menu__link" href="login.php">Events</a></li>
            <li class="menu__item"><a class="menu__link" href="signin.php">Sign in</a></li>


        </ul>
        <p>&copy;2024 Local Community | All Rights Reserved</p>
    </footer>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

</body>

</html>